﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



/******************************************************************** 
 * ***  NAME  :        ***
 * ***  CLASS  :  CSc XXX       *** 
 * ***  ASSIGNMENT :        *** 
 * ***  DUE DATE :        *** 
 * ***  INSTRUCTOR :  GAMRADT       *** 
 * ********************************************************************* ***  DESCRIPTION : <detailed english description of the current assignment> *** ********************************************************************/


namespace HeroNS
{
    public class Hero
    {
        /*********************************************************************** 
        * ***  METHOD  Getters and setters                                                *** 
        * ********************************************************************* 
        * ***  DESCRIPTION :  provides getters and setters for each of the  ***
        * ***                 Hero classes variables. Each return their type***
        * ***                 or is a void statement respectively           *** 
        * ***  INPUT ARGS :  none                                           *** 
        * ***  OUTPUT ARGS :  none                                          ***
        * ***  IN/OUT ARGS :  none                                          ***
        * ***  RETURN :  void                                               *** 
        * ********************************************************************/

        public string Name { get; set; }
        public Global.RaceType Race { get; set; }
        public Global.WeaponType Weapon { get; set; }
        public short Health { get; set; }
        public short Protection { get; set; }
        /*********************************************************************** 
         * ***  METHOD  Hero                                                *** 
         * ********************************************************************* 
         * ***  DESCRIPTION :  Creates a Hero with default settings          *** 
         * ***  INPUT ARGS :  Hero object                                    *** 
         * ***  OUTPUT ARGS :  none                                          ***
         * ***  IN/OUT ARGS :  none                                          ***
         * ***  RETURN :  void                                               *** 
         * ********************************************************************/
        public Hero()
        {
            Name = "Geralt";
            Race = Global.RaceType.WITCHER;
            Weapon = Global.WeaponType.AXE;
            Health = 200;
            Protection = 50;

        }
        /*********************************************************************** 
         * ***  METHOD  Hero()                                                *** 
         * ********************************************************************* 
         * ***  DESCRIPTION :  Creates hero with the given parameters to math a hero   *** 
         * ***  INPUT ARGS :  string name, RaceType, Health, Protection, and weapon type     *** 
         * ***  OUTPUT ARGS :  none                                          ***
         * ***  IN/OUT ARGS :  none                                          ***
         * ***  RETURN :  void                                               *** 
         * ********************************************************************/
        public Hero(string n, Global.RaceType r, short h, short p, Global.WeaponType w)
        {
            Name = n;
            Race = r;
            Health = h;
            Protection = p;
            Weapon = w;
        }
        public Hero(string n)
        {
            Name = n;
            Race = Global.RaceType.WITCHER;
            Weapon = Global.WeaponType.AXE;
            Health = 200;
            Protection = 50;
        }
        public Hero(Global.RaceType r)
        {
            Name = "Geralt";
            Race = r;
            Weapon = Global.WeaponType.AXE;
            Health = 200;
            Protection = 50;
        }
        public Hero(Global.WeaponType w)
        {
            Name = "Geralt";
            Race = Global.RaceType.WITCHER;
            Weapon = w;
            Health = 200;
            Protection = 50;
        }
        /*********************************************************************** 
         * ***  METHOD  Hero                                                *** 
         * ********************************************************************* 
         * ***  DESCRIPTION :  Creates a copy of the Hero                    *** 
         * ***  INPUT ARGS :  Hero object                                    *** 
         * ***  OUTPUT ARGS :  none                                          ***
         * ***  IN/OUT ARGS :  Hero                                          ***
         * ***  RETURN :  void                                               *** 
         * ********************************************************************/
        public Hero(Hero h)
        {
            Name = h.Name;
            Race = h.Race;
            Health = h.Health;
            Protection = h.Protection;
            Weapon = h.Weapon;
        }





    }


}
