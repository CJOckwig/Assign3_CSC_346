﻿using System;

using HeroNS;
class Program
    {
        static void Main(string[] args)
        {
        Hero Test = new Hero("God", Global.RaceType.DRAGON, Global.WeaponType.MACE, 69, 420);

        Hero KobraKid = new Hero(Test);
        KobraKid.Name = "Kobra";
        View.ViewV(Test);

        }
}
