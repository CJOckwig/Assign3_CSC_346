﻿using System;

using HeroNS;
class Program
    {
        static void Main(string[] args)
        {
            Hero JetStar = new Hero();
            View v = new View();
            v.ViewH(JetStar);
        }
}
