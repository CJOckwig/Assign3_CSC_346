﻿using System;

using HeroNS;
class Program
    {
        static void Main(string[] args)
        {
        Hero JetStar = new Hero();

        Hero KobraKid = new Hero(JetStar);
        KobraKid.Name = "Kobra";
        Hero Drac = new Hero("Draculoid", Global.RaceType.VAMPIRE, 420, 69, Global.WeaponType.MACE);
        View.ViewV(Drac);

        }
}
