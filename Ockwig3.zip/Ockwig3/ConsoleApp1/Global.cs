﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroNS
{
    public static class Global
    {
        public enum WeaponType { AXE, MACE, SPELL, SWORD }
        public enum RaceType { DRAGON, VAMPIRE, WITCHER }

    }
}
