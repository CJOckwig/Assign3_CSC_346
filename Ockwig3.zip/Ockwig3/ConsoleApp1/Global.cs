﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroNS
{
    public class Global
    {
        public enum WeaponType { AXE, MACE, SWORD, SPELL }
        public enum RaceType { DRAGON, WITCHER, VAMPIRE }

    }
}
