﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroNS
{
    public class Global
    {
        public enum WEAPON_TYPE { AXE, MACE, SWORD, SPELL }
        public enum RACE_TYPE { DRAGON, WITCHER, VAMPIRE }

    }
}
